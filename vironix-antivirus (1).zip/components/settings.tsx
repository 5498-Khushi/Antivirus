"use client"

import { useState, useEffect } from "react"
import { SettingsIcon, Shield, Bell, Database, Palette, Clock, Zap, AlertTriangle } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { Slider } from "@/components/ui/slider"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"

interface SettingsProps {
  isProtected: boolean
  setIsProtected: (value: boolean) => void
}

export function Settings({ isProtected, setIsProtected }: SettingsProps) {
  const [realTimeProtection, setRealTimeProtection] = useState(true)
  const [autoUpdates, setAutoUpdates] = useState(true)
  const [notifications, setNotifications] = useState(true)
  const [scanSensitivity, setScanSensitivity] = useState([75])
  const [scanSchedule, setScanSchedule] = useState("daily")
  const [scanPriority, setScanPriority] = useState("normal")
  const [updateFrequency, setUpdateFrequency] = useState("automatic")
  const [quarantineAction, setQuarantineAction] = useState("prompt")
  const [theme, setTheme] = useState("rose")
  const [compactMode, setCompactMode] = useState(false)
  const [animations, setAnimations] = useState(true)
  const [soundAlerts, setSoundAlerts] = useState(true)
  const [monitoredExtensions, setMonitoredExtensions] = useState([
    { ext: ".exe", enabled: true, risk: "high", description: "Executable files" },
    { ext: ".bat", enabled: true, risk: "high", description: "Batch script files" },
    { ext: ".cmd", enabled: true, risk: "high", description: "Command script files" },
    { ext: ".scr", enabled: true, risk: "high", description: "Screen saver files" },
    { ext: ".pif", enabled: true, risk: "high", description: "Program information files" },
    { ext: ".vbs", enabled: true, risk: "high", description: "VBScript files" },
    { ext: ".js", enabled: true, risk: "medium", description: "JavaScript files" },
    { ext: ".jse", enabled: true, risk: "medium", description: "JScript encoded files" },
    { ext: ".wsf", enabled: true, risk: "medium", description: "Windows script files" },
    { ext: ".ps1", enabled: true, risk: "high", description: "PowerShell script files" },
    { ext: ".msi", enabled: true, risk: "medium", description: "Windows installer files" },
    { ext: ".reg", enabled: true, risk: "high", description: "Registry files" },
    { ext: ".cpl", enabled: true, risk: "medium", description: "Control panel files" },
    { ext: ".jar", enabled: true, risk: "medium", description: "Java archive files" },
    { ext: ".com", enabled: true, risk: "high", description: "Command files" },
    { ext: ".hta", enabled: true, risk: "high", description: "HTML application files" },
    { ext: ".dll", enabled: true, risk: "medium", description: "Dynamic link library files" },
    { ext: ".lnk", enabled: true, risk: "low", description: "Shortcut files" },
    { ext: ".docm", enabled: true, risk: "medium", description: "Macro-enabled Word documents" },
    { ext: ".xlsm", enabled: true, risk: "medium", description: "Macro-enabled Excel files" },
  ])

  const [currentTheme, setCurrentTheme] = useState("rose")

  const toggleExtension = (ext: string) => {
    setMonitoredExtensions((prev) =>
      prev.map((item) => (item.ext === ext ? { ...item, enabled: !item.enabled } : item)),
    )
  }

  const handleThemeChange = (newTheme: string) => {
    setCurrentTheme(newTheme)
    setTheme(newTheme)

    // Apply theme to document root
    const root = document.documentElement
    root.classList.remove("theme-rose", "theme-blue", "theme-green", "theme-purple")
    root.classList.add(`theme-${newTheme}`)

    // Save theme preference
    localStorage.setItem("vironix-color-theme", newTheme)
  }

  const handleSaveSettings = () => {
    // Save all settings to localStorage
    const settings = {
      realTimeProtection,
      autoUpdates,
      notifications,
      scanSensitivity: scanSensitivity[0],
      scanSchedule,
      scanPriority,
      updateFrequency,
      quarantineAction,
      theme: currentTheme,
      compactMode,
      animations,
      soundAlerts,
      monitoredExtensions,
    }
    localStorage.setItem("vironix-settings", JSON.stringify(settings))

    // Apply theme immediately
    handleThemeChange(currentTheme)

    // Show success feedback
    const button = document.querySelector("[data-save-button]") as HTMLElement
    if (button) {
      button.textContent = "Settings Saved!"
      setTimeout(() => {
        button.textContent = "Save Settings"
      }, 2000)
    }
  }

  const handleResetSettings = () => {
    if (confirm("Are you sure you want to reset all settings to their default values?")) {
      setRealTimeProtection(true)
      setAutoUpdates(true)
      setNotifications(true)
      setScanSensitivity([75])
      setScanSchedule("daily")
      setScanPriority("normal")
      setUpdateFrequency("automatic")
      setQuarantineAction("prompt")
      setCurrentTheme("rose")
      setTheme("rose")
      setCompactMode(false)
      setAnimations(true)
      setSoundAlerts(true)
      setMonitoredExtensions([
        { ext: ".exe", enabled: true, risk: "high", description: "Executable files" },
        { ext: ".bat", enabled: true, risk: "high", description: "Batch script files" },
        { ext: ".cmd", enabled: true, risk: "high", description: "Command script files" },
        { ext: ".scr", enabled: true, risk: "high", description: "Screen saver files" },
        { ext: ".pif", enabled: true, risk: "high", description: "Program information files" },
        { ext: ".vbs", enabled: true, risk: "high", description: "VBScript files" },
        { ext: ".js", enabled: true, risk: "medium", description: "JavaScript files" },
        { ext: ".jse", enabled: true, risk: "medium", description: "JScript encoded files" },
        { ext: ".wsf", enabled: true, risk: "medium", description: "Windows script files" },
        { ext: ".ps1", enabled: true, risk: "high", description: "PowerShell script files" },
        { ext: ".msi", enabled: true, risk: "medium", description: "Windows installer files" },
        { ext: ".reg", enabled: true, risk: "high", description: "Registry files" },
        { ext: ".cpl", enabled: true, risk: "medium", description: "Control panel files" },
        { ext: ".jar", enabled: true, risk: "medium", description: "Java archive files" },
        { ext: ".com", enabled: true, risk: "high", description: "Command files" },
        { ext: ".hta", enabled: true, risk: "high", description: "HTML application files" },
        { ext: ".dll", enabled: true, risk: "medium", description: "Dynamic link library files" },
        { ext: ".lnk", enabled: true, risk: "low", description: "Shortcut files" },
        { ext: ".docm", enabled: true, risk: "medium", description: "Macro-enabled Word documents" },
        { ext: ".xlsm", enabled: true, risk: "medium", description: "Macro-enabled Excel files" },
      ])

      // Reset theme
      handleThemeChange("rose")
      localStorage.removeItem("vironix-settings")
    }
  }

  // Load saved settings on component mount
  useEffect(() => {
    const savedSettings = localStorage.getItem("vironix-settings")
    const savedTheme = localStorage.getItem("vironix-color-theme")

    if (savedSettings) {
      try {
        const settings = JSON.parse(savedSettings)
        if (settings.monitoredExtensions) {
          setMonitoredExtensions(settings.monitoredExtensions)
        }
        if (settings.theme) {
          setCurrentTheme(settings.theme)
          setTheme(settings.theme)
        }
      } catch (error) {
        console.error("Error loading settings:", error)
      }
    }

    if (savedTheme) {
      setCurrentTheme(savedTheme)
      setTheme(savedTheme)
      handleThemeChange(savedTheme)
    }
  }, [])

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold gradient-text-theme animate-shimmer">Settings</h1>
          <p className="text-rose-600 dark:text-rose-400 mt-1">Configure your antivirus protection and preferences</p>
        </div>
        <div className="flex items-center space-x-2">
          <div
            className={`w-3 h-3 rounded-full animate-pulse-soft ${isProtected ? "bg-green-500" : "bg-red-500"}`}
          ></div>
          <span className="text-sm font-medium">{isProtected ? "Protection Active" : "Protection Disabled"}</span>
        </div>
      </div>

      {/* Protection Settings */}
      <Card className="bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20 border-green-200 dark:border-green-700 rounded-xl shadow-lg transition-all duration-300 hover:shadow-xl hover:scale-[1.01] card-hover">
        <CardHeader>
          <CardTitle className="flex items-center text-green-800 dark:text-green-300">
            <Shield className="h-5 w-5 mr-2 animate-pulse-soft" />
            Protection Settings
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between p-3 bg-white dark:bg-gray-800 rounded-lg border border-green-200 dark:border-gray-600 transition-all duration-200 hover:bg-green-50 dark:hover:bg-gray-700/50">
            <div>
              <h3 className="font-semibold text-green-800 dark:text-green-300">Master Protection Switch</h3>
              <p className="text-sm text-green-600 dark:text-green-500">Enable or disable all protection features</p>
            </div>
            <Switch
              checked={isProtected}
              onCheckedChange={setIsProtected}
              className="data-[state=checked]:bg-green-500"
            />
          </div>

          <div className="flex items-center justify-between p-3 bg-white dark:bg-gray-800 rounded-lg border border-green-200 dark:border-gray-600 transition-all duration-200 hover:bg-green-50 dark:hover:bg-gray-700/50">
            <div>
              <h3 className="font-semibold text-green-800 dark:text-green-300">Real-time Protection</h3>
              <p className="text-sm text-green-600 dark:text-green-500">Continuously monitor your system for threats</p>
            </div>
            <Switch
              checked={realTimeProtection && isProtected}
              onCheckedChange={setRealTimeProtection}
              disabled={!isProtected}
              className="data-[state=checked]:bg-green-500"
            />
          </div>

          <div className="flex items-center justify-between p-3 bg-white dark:bg-gray-800 rounded-lg border border-green-200 dark:border-gray-600 transition-all duration-200 hover:bg-green-50 dark:hover:bg-gray-700/50">
            <div>
              <h3 className="font-semibold text-green-800 dark:text-green-300">Automatic Updates</h3>
              <p className="text-sm text-green-600 dark:text-green-500">
                Keep virus definitions up to date automatically
              </p>
            </div>
            <Switch
              checked={autoUpdates}
              onCheckedChange={setAutoUpdates}
              className="data-[state=checked]:bg-green-500"
            />
          </div>

          <div className="p-3 bg-white dark:bg-gray-800 rounded-lg border border-green-200 dark:border-gray-600">
            <h3 className="font-semibold text-green-800 dark:text-green-300 mb-3">Scan Priority</h3>
            <RadioGroup value={scanPriority} onValueChange={setScanPriority} className="space-y-2">
              <div className="flex items-center space-x-2 p-2 rounded hover:bg-green-50 dark:hover:bg-gray-700/50 transition-all duration-200">
                <RadioGroupItem value="low" id="priority-low" className="border-green-500 text-green-500" />
                <Label htmlFor="priority-low" className="flex-1 cursor-pointer">
                  <span className="font-medium">Low Priority</span>
                  <p className="text-xs text-green-600 dark:text-green-500">Minimal system impact, slower scans</p>
                </Label>
              </div>
              <div className="flex items-center space-x-2 p-2 rounded hover:bg-green-50 dark:hover:bg-gray-700/50 transition-all duration-200">
                <RadioGroupItem value="normal" id="priority-normal" className="border-green-500 text-green-500" />
                <Label htmlFor="priority-normal" className="flex-1 cursor-pointer">
                  <span className="font-medium">Normal Priority</span>
                  <p className="text-xs text-green-600 dark:text-green-500">Balanced performance and speed</p>
                </Label>
              </div>
              <div className="flex items-center space-x-2 p-2 rounded hover:bg-green-50 dark:hover:bg-gray-700/50 transition-all duration-200">
                <RadioGroupItem value="high" id="priority-high" className="border-green-500 text-green-500" />
                <Label htmlFor="priority-high" className="flex-1 cursor-pointer">
                  <span className="font-medium">High Priority</span>
                  <p className="text-xs text-green-600 dark:text-green-500">Maximum speed, higher system usage</p>
                </Label>
              </div>
            </RadioGroup>
          </div>

          <div className="p-3 bg-white dark:bg-gray-800 rounded-lg border border-green-200 dark:border-gray-600">
            <h3 className="font-semibold text-green-800 dark:text-green-300 mb-3">Threat Detection Action</h3>
            <RadioGroup value={quarantineAction} onValueChange={setQuarantineAction} className="space-y-2">
              <div className="flex items-center space-x-2 p-2 rounded hover:bg-green-50 dark:hover:bg-gray-700/50 transition-all duration-200">
                <RadioGroupItem value="prompt" id="action-prompt" className="border-green-500 text-green-500" />
                <Label htmlFor="action-prompt" className="flex-1 cursor-pointer">
                  <span className="font-medium">Prompt User</span>
                  <p className="text-xs text-green-600 dark:text-green-500">Ask what to do with detected threats</p>
                </Label>
              </div>
              <div className="flex items-center space-x-2 p-2 rounded hover:bg-green-50 dark:hover:bg-gray-700/50 transition-all duration-200">
                <RadioGroupItem value="quarantine" id="action-quarantine" className="border-green-500 text-green-500" />
                <Label htmlFor="action-quarantine" className="flex-1 cursor-pointer">
                  <span className="font-medium">Auto Quarantine</span>
                  <p className="text-xs text-green-600 dark:text-green-500">Automatically quarantine all threats</p>
                </Label>
              </div>
              <div className="flex items-center space-x-2 p-2 rounded hover:bg-green-50 dark:hover:bg-gray-700/50 transition-all duration-200">
                <RadioGroupItem value="delete" id="action-delete" className="border-green-500 text-green-500" />
                <Label htmlFor="action-delete" className="flex-1 cursor-pointer">
                  <span className="font-medium">Auto Delete</span>
                  <p className="text-xs text-green-600 dark:text-green-500">Automatically delete detected threats</p>
                </Label>
              </div>
            </RadioGroup>
          </div>

          <div className="p-3 bg-white dark:bg-gray-800 rounded-lg border border-green-200 dark:border-gray-600">
            <h3 className="font-semibold text-green-800 dark:text-green-300 mb-2">Scan Sensitivity</h3>
            <p className="text-sm text-green-600 dark:text-green-500 mb-4">
              Adjust how aggressively the scanner detects potential threats
            </p>
            <div className="space-y-2">
              <Slider
                value={scanSensitivity}
                onValueChange={setScanSensitivity}
                max={100}
                step={1}
                className="w-full"
              />
              <div className="flex justify-between text-xs text-green-600 dark:text-green-500">
                <span>Low (Conservative)</span>
                <span className="font-medium">{scanSensitivity[0]}%</span>
                <span>High (Aggressive)</span>
              </div>
            </div>
          </div>

          <div className="p-3 bg-white dark:bg-gray-800 rounded-lg border border-green-200 dark:border-gray-600">
            <h3 className="font-semibold text-green-800 dark:text-green-300 mb-2">Scheduled Scan</h3>
            <p className="text-sm text-green-600 dark:text-green-500 mb-4">
              Automatically run system scans at regular intervals
            </p>
            <Select value={scanSchedule} onValueChange={setScanSchedule}>
              <SelectTrigger className="w-full">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="disabled">Disabled</SelectItem>
                <SelectItem value="daily">Daily at 2:00 AM</SelectItem>
                <SelectItem value="weekly">Weekly on Sunday</SelectItem>
                <SelectItem value="monthly">Monthly on 1st</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Update Settings */}
      <Card className="bg-gradient-to-br from-purple-50 to-violet-50 dark:from-purple-900/20 dark:to-violet-900/20 border-purple-200 dark:border-purple-700 rounded-xl shadow-lg transition-all duration-300 hover:shadow-xl hover:scale-[1.01] card-hover">
        <CardHeader>
          <CardTitle className="flex items-center text-purple-800 dark:text-purple-300">
            <Database className="h-5 w-5 mr-2 animate-pulse-soft" />
            Update Settings
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="p-3 bg-white dark:bg-gray-800 rounded-lg border border-purple-200 dark:border-gray-600">
            <h3 className="font-semibold text-purple-800 dark:text-purple-300 mb-3">Update Frequency</h3>
            <RadioGroup value={updateFrequency} onValueChange={setUpdateFrequency} className="space-y-2">
              <div className="flex items-center space-x-2 p-2 rounded hover:bg-purple-50 dark:hover:bg-gray-700/50 transition-all duration-200">
                <RadioGroupItem value="automatic" id="update-auto" className="border-purple-500 text-purple-500" />
                <Label htmlFor="update-auto" className="flex-1 cursor-pointer">
                  <span className="font-medium">Automatic Updates</span>
                  <p className="text-xs text-purple-600 dark:text-purple-500">Update immediately when available</p>
                </Label>
              </div>
              <div className="flex items-center space-x-2 p-2 rounded hover:bg-purple-50 dark:hover:bg-gray-700/50 transition-all duration-200">
                <RadioGroupItem value="daily" id="update-daily" className="border-purple-500 text-purple-500" />
                <Label htmlFor="update-daily" className="flex-1 cursor-pointer">
                  <span className="font-medium">Daily Updates</span>
                  <p className="text-xs text-purple-600 dark:text-purple-500">Check for updates once per day</p>
                </Label>
              </div>
              <div className="flex items-center space-x-2 p-2 rounded hover:bg-purple-50 dark:hover:bg-gray-700/50 transition-all duration-200">
                <RadioGroupItem value="manual" id="update-manual" className="border-purple-500 text-purple-500" />
                <Label htmlFor="update-manual" className="flex-1 cursor-pointer">
                  <span className="font-medium">Manual Updates</span>
                  <p className="text-xs text-purple-600 dark:text-purple-500">Update only when manually triggered</p>
                </Label>
              </div>
            </RadioGroup>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 bg-white dark:bg-gray-800 rounded-lg border border-purple-200 dark:border-gray-600 transition-all duration-300 hover:scale-105">
              <h4 className="font-semibold text-purple-800 dark:text-purple-300 mb-2">Virus Definitions</h4>
              <p className="text-sm text-purple-600 dark:text-purple-500 mb-2">Last updated: 2 hours ago</p>
              <p className="text-sm text-purple-600 dark:text-purple-500 mb-4">Version: 2024.01.15.02</p>
              <Button
                size="sm"
                className="w-full bg-purple-500 hover:bg-purple-600 text-white transition-all duration-300 hover:scale-105 hover:glow-purple"
              >
                <Database className="h-4 w-4 mr-2" />
                Update Now
              </Button>
            </div>

            <div className="p-4 bg-white dark:bg-gray-800 rounded-lg border border-purple-200 dark:border-gray-600 transition-all duration-300 hover:scale-105">
              <h4 className="font-semibold text-purple-800 dark:text-purple-300 mb-2">Threat Intelligence</h4>
              <p className="text-sm text-purple-600 dark:text-purple-500 mb-2">Last updated: 1 hour ago</p>
              <p className="text-sm text-purple-600 dark:text-purple-500 mb-4">Sources: 15 active feeds</p>
              <Button
                size="sm"
                variant="outline"
                className="w-full border-purple-300 text-purple-700 hover:bg-purple-100 dark:border-purple-600 dark:text-purple-300 dark:hover:bg-purple-900/20 transition-all duration-300 hover:scale-105"
              >
                <Zap className="h-4 w-4 mr-2" />
                View Sources
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Virus Extensions Management */}
      <Card className="bg-gradient-to-br from-red-50 to-orange-50 dark:from-red-900/20 dark:to-orange-900/20 border-red-200 dark:border-red-700 rounded-xl shadow-lg transition-all duration-300 hover:shadow-xl hover:scale-[1.01] card-hover">
        <CardHeader>
          <CardTitle className="flex items-center text-red-800 dark:text-red-300">
            <AlertTriangle className="h-5 w-5 mr-2 animate-float" />
            Monitored File Extensions
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="p-3 bg-white dark:bg-gray-800 rounded-lg border border-red-200 dark:border-gray-600">
            <h3 className="font-semibold text-red-800 dark:text-red-300 mb-2">Threat Detection Extensions</h3>
            <p className="text-sm text-red-600 dark:text-red-500 mb-4">
              Configure which file extensions should be scanned and treated as potential threats
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 max-h-64 overflow-y-auto">
              {monitoredExtensions.map((item) => (
                <div
                  key={item.ext}
                  className={`flex items-center justify-between p-3 rounded-lg border transition-all duration-200 hover:scale-[1.02] cursor-pointer group ${
                    item.enabled
                      ? "bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-700"
                      : "bg-gray-50 dark:bg-gray-700 border-gray-300 dark:border-gray-500 opacity-60"
                  }`}
                >
                  <div className="flex items-center space-x-3 flex-1">
                    <Switch
                      checked={item.enabled}
                      onCheckedChange={() => toggleExtension(item.ext)}
                      className="data-[state=checked]:bg-red-500"
                    />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center space-x-2">
                        <span className="font-mono font-semibold text-red-800 dark:text-red-300">{item.ext}</span>
                        <Badge
                          variant={
                            item.risk === "high" ? "destructive" : item.risk === "medium" ? "default" : "secondary"
                          }
                          className="text-xs"
                        >
                          {item.risk.toUpperCase()}
                        </Badge>
                      </div>
                      <p className="text-xs text-red-600 dark:text-red-500 truncate">{item.description}</p>
                    </div>
                  </div>

                  {/* Hover popup with detailed info */}
                  <div className="absolute top-0 right-0 bg-red-600 text-white text-xs px-3 py-2 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300 animate-bounce-in z-10 whitespace-nowrap">
                    <div className="text-center">
                      <div className="font-bold">{item.ext}</div>
                      <div>{item.risk} risk</div>
                      <div className="text-xs mt-1">{item.enabled ? "Monitored" : "Ignored"}</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-4 p-3 bg-red-100 dark:bg-red-900/30 rounded-lg border border-red-200 dark:border-red-700">
              <div className="flex items-center space-x-2 mb-2">
                <AlertTriangle className="h-4 w-4 text-red-600" />
                <span className="font-semibold text-red-800 dark:text-red-300">Security Notice</span>
              </div>
              <p className="text-sm text-red-700 dark:text-red-400">
                Disabling monitoring for high-risk extensions may leave your system vulnerable to threats. Only disable
                if you're certain about the safety of these file types.
              </p>
            </div>

            <div className="flex space-x-2 mt-4">
              <Button
                size="sm"
                onClick={() => setMonitoredExtensions((prev) => prev.map((item) => ({ ...item, enabled: true })))}
                className="flex-1 bg-red-500 hover:bg-red-600 text-white transition-all duration-300 hover:scale-105"
              >
                Enable All
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={() =>
                  setMonitoredExtensions((prev) => prev.map((item) => ({ ...item, enabled: item.risk === "high" })))
                }
                className="flex-1 border-red-300 text-red-700 hover:bg-red-100 dark:border-red-600 dark:text-red-300 dark:hover:bg-red-900/20 transition-all duration-300 hover:scale-105"
              >
                High Risk Only
              </Button>
            </div>
          </div>

          {/* Extension Statistics */}
          <div className="grid grid-cols-3 gap-4">
            <div className="text-center p-3 bg-white dark:bg-gray-800 rounded-lg border border-red-200 dark:border-gray-600 transition-all duration-300 hover:scale-105 cursor-pointer group relative">
              <div className="text-2xl font-bold text-red-700 dark:text-red-400">
                {monitoredExtensions.filter((item) => item.enabled && item.risk === "high").length}
              </div>
              <div className="text-sm text-red-600 dark:text-red-500">High Risk</div>

              {/* Hover popup */}
              <div className="absolute -top-2 -right-2 bg-red-500 text-white text-xs px-2 py-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300 animate-bounce-in">
                🔴 Critical
              </div>
            </div>

            <div className="text-center p-3 bg-white dark:bg-gray-800 rounded-lg border border-red-200 dark:border-gray-600 transition-all duration-300 hover:scale-105 cursor-pointer group relative">
              <div className="text-2xl font-bold text-orange-700 dark:text-orange-400">
                {monitoredExtensions.filter((item) => item.enabled && item.risk === "medium").length}
              </div>
              <div className="text-sm text-orange-600 dark:text-orange-500">Medium Risk</div>

              {/* Hover popup */}
              <div className="absolute -top-2 -right-2 bg-orange-500 text-white text-xs px-2 py-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300 animate-bounce-in">
                🟡 Caution
              </div>
            </div>

            <div className="text-center p-3 bg-white dark:bg-gray-800 rounded-lg border border-red-200 dark:border-gray-600 transition-all duration-300 hover:scale-105 cursor-pointer group relative">
              <div className="text-2xl font-bold text-yellow-700 dark:text-yellow-400">
                {monitoredExtensions.filter((item) => item.enabled && item.risk === "low").length}
              </div>
              <div className="text-sm text-yellow-600 dark:text-yellow-500">Low Risk</div>

              {/* Hover popup */}
              <div className="absolute -top-2 -right-2 bg-yellow-500 text-white text-xs px-2 py-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300 animate-bounce-in">
                🟢 Safe
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Notification Settings */}
      <Card className="bg-gradient-to-br from-blue-50 to-cyan-50 dark:from-blue-900/20 dark:to-cyan-900/20 border-blue-200 dark:border-blue-700 rounded-xl shadow-lg transition-all duration-300 hover:shadow-xl hover:scale-[1.01] card-hover">
        <CardHeader>
          <CardTitle className="flex items-center text-blue-800 dark:text-blue-300">
            <Bell className="h-5 w-5 mr-2 animate-pulse-soft" />
            Notification Settings
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between p-3 bg-white dark:bg-gray-800 rounded-lg border border-blue-200 dark:border-gray-600 transition-all duration-200 hover:bg-blue-50 dark:hover:bg-gray-700/50">
            <div>
              <h3 className="font-semibold text-blue-800 dark:text-blue-300">Desktop Notifications</h3>
              <p className="text-sm text-blue-600 dark:text-blue-500">Show alerts when threats are detected</p>
            </div>
            <Switch
              checked={notifications}
              onCheckedChange={setNotifications}
              className="data-[state=checked]:bg-blue-500"
            />
          </div>

          <div className="flex items-center justify-between p-3 bg-white dark:bg-gray-800 rounded-lg border border-blue-200 dark:border-gray-600 transition-all duration-200 hover:bg-blue-50 dark:hover:bg-gray-700/50">
            <div>
              <h3 className="font-semibold text-blue-800 dark:text-blue-300">Sound Alerts</h3>
              <p className="text-sm text-blue-600 dark:text-blue-500">Play sound when threats are detected</p>
            </div>
            <Switch
              checked={soundAlerts}
              onCheckedChange={setSoundAlerts}
              className="data-[state=checked]:bg-blue-500"
            />
          </div>

          <div className="flex items-center justify-between p-3 bg-white dark:bg-gray-800 rounded-lg border border-blue-200 dark:border-gray-600 transition-all duration-200 hover:bg-blue-50 dark:hover:bg-gray-700/50">
            <div>
              <h3 className="font-semibold text-blue-800 dark:text-blue-300">Scan Completion Alerts</h3>
              <p className="text-sm text-blue-600 dark:text-blue-500">Notify when scans are finished</p>
            </div>
            <Switch checked={true} className="data-[state=checked]:bg-blue-500" />
          </div>

          <div className="flex items-center justify-between p-3 bg-white dark:bg-gray-800 rounded-lg border border-blue-200 dark:border-gray-600 transition-all duration-200 hover:bg-blue-50 dark:hover:bg-gray-700/50">
            <div>
              <h3 className="font-semibold text-blue-800 dark:text-blue-300">Update Notifications</h3>
              <p className="text-sm text-blue-600 dark:text-blue-500">Alert when virus definitions are updated</p>
            </div>
            <Switch checked={false} className="data-[state=checked]:bg-blue-500" />
          </div>
        </CardContent>
      </Card>

      {/* Appearance Settings */}
      <Card className="bg-gradient-to-br from-rose-50/50 to-pink-50/50 dark:from-gray-800/50 dark:to-gray-700/50 border-rose-200 dark:border-gray-600 rounded-xl shadow-lg transition-all duration-300 hover:shadow-xl hover:scale-[1.01] card-hover">
        <CardHeader>
          <CardTitle className="flex items-center text-rose-800 dark:text-rose-300">
            <Palette className="h-5 w-5 mr-2 animate-pulse-soft" />
            Appearance Settings
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="p-3 bg-white dark:bg-gray-800 rounded-lg border border-rose-200 dark:border-gray-600">
            <h3 className="font-semibold text-rose-800 dark:text-rose-300 mb-2">Theme</h3>
            <p className="text-sm text-rose-600 dark:text-rose-500 mb-4">Choose your preferred color scheme</p>
            <Select value={currentTheme} onValueChange={handleThemeChange}>
              <SelectTrigger className="w-full">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="rose">Rolex Pink Day-Date</SelectItem>
                <SelectItem value="blue">Ocean Blue</SelectItem>
                <SelectItem value="green">Forest Green</SelectItem>
                <SelectItem value="purple">Royal Purple</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center justify-between p-3 bg-white dark:bg-gray-800 rounded-lg border border-rose-200 dark:border-gray-600 transition-all duration-200 hover:bg-rose-50 dark:hover:bg-gray-700/50">
            <div>
              <h3 className="font-semibold text-rose-800 dark:text-rose-300">Compact Mode</h3>
              <p className="text-sm text-rose-600 dark:text-rose-500">Use smaller interface elements to save space</p>
            </div>
            <Switch
              checked={compactMode}
              onCheckedChange={setCompactMode}
              className="data-[state=checked]:bg-rose-500"
            />
          </div>

          <div className="flex items-center justify-between p-3 bg-white dark:bg-gray-800 rounded-lg border border-rose-200 dark:border-gray-600 transition-all duration-200 hover:bg-rose-50 dark:hover:bg-gray-700/50">
            <div>
              <h3 className="font-semibold text-rose-800 dark:text-rose-300">Animations</h3>
              <p className="text-sm text-rose-600 dark:text-rose-500">Enable smooth transitions and effects</p>
            </div>
            <Switch checked={animations} onCheckedChange={setAnimations} className="data-[state=checked]:bg-rose-500" />
          </div>
        </CardContent>
      </Card>

      {/* Action Buttons */}
      <Card className="bg-gradient-to-br from-orange-50 to-amber-50 dark:from-orange-900/20 dark:to-amber-900/20 border-orange-200 dark:border-orange-700 rounded-xl shadow-lg">
        <CardContent className="p-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <Button
              onClick={handleSaveSettings}
              data-save-button
              className="flex-1 bg-gradient-to-r from-orange-500 to-amber-500 hover:from-orange-600 hover:to-amber-600 text-white transition-all duration-300 hover:scale-105 hover:glow-orange"
            >
              <SettingsIcon className="h-4 w-4 mr-2" />
              Save Settings
            </Button>
            <Button
              variant="outline"
              onClick={handleResetSettings}
              className="flex-1 border-orange-300 text-orange-700 hover:bg-orange-100 dark:border-orange-600 dark:text-orange-300 dark:hover:bg-orange-900/20 transition-all duration-300 hover:scale-105"
            >
              <Clock className="h-4 w-4 mr-2" />
              Reset to Defaults
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
