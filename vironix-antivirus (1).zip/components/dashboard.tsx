"use client"

import { Shield, Activity, AlertTriangle, Clock } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Button } from "@/components/ui/button"

interface DashboardProps {
  isProtected: boolean
  quarantinedFiles: any[]
  scanResults: any[]
  onQuickScan?: () => void
}

export function Dashboard({ isProtected, quarantinedFiles, scanResults, onQuickScan }: DashboardProps) {
  const handleQuickScan = () => {
    if (onQuickScan) {
      onQuickScan()
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold gradient-text-theme">Security Dashboard</h1>
          <p className="text-rose-600 dark:text-rose-400 mt-1">Your system is protected and secure</p>
        </div>
        <Button
          onClick={handleQuickScan}
          className="bg-gradient-to-r from-rose-500 to-pink-500 hover:from-rose-600 hover:to-pink-600 text-white rounded-xl shadow-lg transition-all duration-300 hover:scale-105 hover:glow-rose group relative"
        >
          <Activity className="h-4 w-4 mr-2 animate-float" />
          Quick Scan
          {/* Hover popup */}
          <div className="absolute -top-12 left-1/2 transform -translate-x-1/2 bg-rose-600 text-white text-xs px-3 py-2 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300 animate-bounce-in whitespace-nowrap">
            🔍 Start Quick System Scan
          </div>
        </Button>
      </div>

      {/* Status Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20 border-green-200 dark:border-green-700 rounded-xl shadow-lg transition-all duration-300 hover:shadow-xl hover:scale-[1.02] card-hover cursor-pointer group relative">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center text-green-800 dark:text-green-300">
              <Shield className="h-5 w-5 mr-2 animate-float" />
              Protection
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-700 dark:text-green-400 animate-bounce-in">
              {isProtected ? "Active" : "Disabled"}
            </div>
            <p className="text-sm text-green-600 dark:text-green-500">Real-time scanning enabled</p>
          </CardContent>

          {/* Hover popup */}
          <div className="absolute -top-2 -right-2 bg-green-500 text-white text-xs px-2 py-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300 animate-bounce-in">
            🛡️ {isProtected ? "Secure" : "At Risk"}
          </div>
        </Card>

        <Card className="bg-gradient-to-br from-blue-50 to-cyan-50 dark:from-blue-900/20 dark:to-cyan-900/20 border-blue-200 dark:border-blue-700 rounded-xl shadow-lg transition-all duration-300 hover:shadow-xl hover:scale-[1.02] card-hover cursor-pointer group relative">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center text-blue-800 dark:text-blue-300">
              <Activity className="h-5 w-5 mr-2 animate-float" />
              Last Scan
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-700 dark:text-blue-400 animate-bounce-in">Clean</div>
            <p className="text-sm text-blue-600 dark:text-blue-500">2 hours ago</p>
          </CardContent>

          {/* Hover popup */}
          <div className="absolute -top-2 -right-2 bg-blue-500 text-white text-xs px-2 py-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300 animate-bounce-in">
            ✅ No Threats
          </div>
        </Card>

        <Card className="bg-gradient-to-br from-orange-50 to-amber-50 dark:from-orange-900/20 dark:to-amber-900/20 border-orange-200 dark:border-orange-700 rounded-xl shadow-lg transition-all duration-300 hover:shadow-xl hover:scale-[1.02] card-hover cursor-pointer group relative">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center text-orange-800 dark:text-orange-300">
              <AlertTriangle className="h-5 w-5 mr-2 animate-float" />
              Quarantine
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-orange-700 dark:text-orange-400 animate-bounce-in">
              {quarantinedFiles.length}
            </div>
            <p className="text-sm text-orange-600 dark:text-orange-500">Items isolated</p>
          </CardContent>

          {/* Hover popup */}
          <div className="absolute -top-2 -right-2 bg-orange-500 text-white text-xs px-2 py-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300 animate-bounce-in">
            🔒 {quarantinedFiles.length} Isolated
          </div>
        </Card>

        <Card className="bg-gradient-to-br from-purple-50 to-violet-50 dark:from-purple-900/20 dark:to-violet-900/20 border-purple-200 dark:border-purple-700 rounded-xl shadow-lg transition-all duration-300 hover:shadow-xl hover:scale-[1.02] card-hover cursor-pointer group relative">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center text-purple-800 dark:text-purple-300">
              <Clock className="h-5 w-5 mr-2 animate-float" />
              Updates
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-700 dark:text-purple-400 animate-bounce-in">Current</div>
            <p className="text-sm text-purple-600 dark:text-purple-500">Database up to date</p>
          </CardContent>

          {/* Hover popup */}
          <div className="absolute -top-2 -right-2 bg-purple-500 text-white text-xs px-2 py-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300 animate-bounce-in">
            📡 Latest
          </div>
        </Card>
      </div>

      {/* System Health */}
      <Card className="bg-gradient-to-br from-rose-50/50 to-pink-50/50 dark:from-gray-800/50 dark:to-gray-700/50 border-rose-200 dark:border-gray-600 rounded-xl shadow-lg transition-all duration-300 hover:shadow-xl hover:scale-[1.01] card-hover">
        <CardHeader>
          <CardTitle className="text-rose-800 dark:text-rose-300">System Health</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="group cursor-pointer relative">
            <div className="flex justify-between text-sm mb-2">
              <span className="text-rose-700 dark:text-rose-400">CPU Usage</span>
              <span className="text-rose-600 dark:text-rose-500">23%</span>
            </div>
            <Progress value={23} className="h-2 transition-all duration-300 group-hover:h-3" />

            {/* Hover popup */}
            <div className="absolute top-0 right-0 bg-rose-500 text-white text-xs px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity duration-300 animate-bounce-in">
              💻 Normal Usage
            </div>
          </div>

          <div className="group cursor-pointer relative">
            <div className="flex justify-between text-sm mb-2">
              <span className="text-rose-700 dark:text-rose-400">Memory Usage</span>
              <span className="text-rose-600 dark:text-rose-500">67%</span>
            </div>
            <Progress value={67} className="h-2 transition-all duration-300 group-hover:h-3" />

            {/* Hover popup */}
            <div className="absolute top-0 right-0 bg-orange-500 text-white text-xs px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity duration-300 animate-bounce-in">
              🧠 Moderate Usage
            </div>
          </div>

          <div className="group cursor-pointer relative">
            <div className="flex justify-between text-sm mb-2">
              <span className="text-rose-700 dark:text-rose-400">Disk Usage</span>
              <span className="text-rose-600 dark:text-rose-500">45%</span>
            </div>
            <Progress value={45} className="h-2 transition-all duration-300 group-hover:h-3" />

            {/* Hover popup */}
            <div className="absolute top-0 right-0 bg-green-500 text-white text-xs px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity duration-300 animate-bounce-in">
              💾 Good Space
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Recent Activity */}
      <Card className="bg-gradient-to-br from-rose-50/50 to-pink-50/50 dark:from-gray-800/50 dark:to-gray-700/50 border-rose-200 dark:border-gray-600 rounded-xl shadow-lg transition-all duration-300 hover:shadow-xl hover:scale-[1.01] card-hover">
        <CardHeader>
          <CardTitle className="text-rose-800 dark:text-rose-300">Recent Activity</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            <div className="flex items-center space-x-3 p-3 bg-green-50 dark:bg-green-900/20 rounded-lg transition-all duration-300 hover:scale-[1.01] cursor-pointer group relative">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse-soft"></div>
              <div className="flex-1">
                <p className="text-sm font-medium text-green-800 dark:text-green-300">Full system scan completed</p>
                <p className="text-xs text-green-600 dark:text-green-500">No threats detected</p>
              </div>
              <span className="text-xs text-green-500">2h ago</span>

              {/* Hover popup */}
              <div className="absolute -top-2 -right-2 bg-green-500 text-white text-xs px-2 py-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300 animate-bounce-in">
                ✅ Clean
              </div>
            </div>

            <div className="flex items-center space-x-3 p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg transition-all duration-300 hover:scale-[1.01] cursor-pointer group relative">
              <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse-soft"></div>
              <div className="flex-1">
                <p className="text-sm font-medium text-blue-800 dark:text-blue-300">Virus definitions updated</p>
                <p className="text-xs text-blue-600 dark:text-blue-500">Latest signatures installed</p>
              </div>
              <span className="text-xs text-blue-500">4h ago</span>

              {/* Hover popup */}
              <div className="absolute -top-2 -right-2 bg-blue-500 text-white text-xs px-2 py-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300 animate-bounce-in">
                📡 Updated
              </div>
            </div>

            <div className="flex items-center space-x-3 p-3 bg-orange-50 dark:bg-orange-900/20 rounded-lg transition-all duration-300 hover:scale-[1.01] cursor-pointer group relative">
              <div className="w-2 h-2 bg-orange-500 rounded-full animate-pulse-soft"></div>
              <div className="flex-1">
                <p className="text-sm font-medium text-orange-800 dark:text-orange-300">Suspicious file quarantined</p>
                <p className="text-xs text-orange-600 dark:text-orange-500">malware.exe moved to quarantine</p>
              </div>
              <span className="text-xs text-orange-500">1d ago</span>

              {/* Hover popup */}
              <div className="absolute -top-2 -right-2 bg-orange-500 text-white text-xs px-2 py-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300 animate-bounce-in">
                🔒 Secured
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
