"use client"

import { useState } from "react"
import { Search, Play, Square, FileText, Trash2, AlertTriangle } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { FolderSelector } from "@/components/folder-selector"

interface ScannerProps {
  scanResults: any[]
  setScanResults: (results: any[]) => void
  quarantinedFiles: any[]
  setQuarantinedFiles: (files: any[]) => void
}

export function Scanner({ scanResults, setScanResults, quarantinedFiles, setQuarantinedFiles }: ScannerProps) {
  const [isScanning, setIsScanning] = useState(false)
  const [scanProgress, setScanProgress] = useState(0)
  const [scanType, setScanType] = useState("")
  const [selectedFolders, setSelectedFolders] = useState<string[]>([])
  const [currentFile, setCurrentFile] = useState("")
  const [filesScanned, setFilesScanned] = useState(0)
  const [threatsFound, setThreatsFound] = useState(0)

  const simulateScan = (type: string, folders?: string[]) => {
    setIsScanning(true)
    setScanProgress(0)
    setScanType(type)
    setFilesScanned(0)
    setThreatsFound(0)
    setCurrentFile("")

    // Get monitored extensions from localStorage
    const savedSettings = localStorage.getItem("vironix-settings")
    let monitoredExtensions = [
      {
        ext: ".exe",
        enabled: true,
        risk: "high",
        threats: ["Trojan.Win32.Generic", "Malware.Generic", "PUP.Optional"],
      },
      { ext: ".bat", enabled: true, risk: "high", threats: ["Script.Malicious", "Trojan.Script", "Worm.VBS"] },
      { ext: ".cmd", enabled: true, risk: "high", threats: ["Script.Malicious", "Trojan.Script", "Worm.CMD"] },
      { ext: ".scr", enabled: true, risk: "high", threats: ["Trojan.Screensaver", "Malware.Fake", "Virus.Generic"] },
      { ext: ".pif", enabled: true, risk: "high", threats: ["Trojan.PIF", "Malware.Legacy", "Virus.DOS"] },
      { ext: ".vbs", enabled: true, risk: "high", threats: ["Script.VBS.Malicious", "Trojan.VBS", "Worm.Script"] },
      { ext: ".js", enabled: true, risk: "medium", threats: ["Trojan.JS.Miner", "Adware.JS", "PUP.JS.Generic"] },
      { ext: ".jse", enabled: true, risk: "medium", threats: ["Script.JSE.Encoded", "Trojan.JSE", "Malware.Script"] },
      { ext: ".wsf", enabled: true, risk: "medium", threats: ["Script.WSF.Malicious", "Trojan.WSF", "Worm.Windows"] },
      {
        ext: ".ps1",
        enabled: true,
        risk: "high",
        threats: ["PowerShell.Malicious", "Trojan.PS1", "Script.PowerShell"],
      },
      { ext: ".msi", enabled: true, risk: "medium", threats: ["Installer.Malicious", "PUP.MSI", "Trojan.Installer"] },
      {
        ext: ".reg",
        enabled: true,
        risk: "high",
        threats: ["Registry.Malicious", "Trojan.Registry", "Malware.RegEdit"],
      },
      {
        ext: ".cpl",
        enabled: true,
        risk: "medium",
        threats: ["ControlPanel.Malicious", "Trojan.CPL", "Malware.Control"],
      },
      { ext: ".jar", enabled: true, risk: "medium", threats: ["Java.Malicious", "Trojan.JAR", "Adware.Java"] },
      { ext: ".com", enabled: true, risk: "high", threats: ["DOS.Malicious", "Trojan.COM", "Virus.Legacy"] },
      {
        ext: ".hta",
        enabled: true,
        risk: "high",
        threats: ["HTML.Application.Malicious", "Trojan.HTA", "Script.HTML"],
      },
      { ext: ".dll", enabled: true, risk: "medium", threats: ["Library.Malicious", "Trojan.DLL", "Backdoor.Library"] },
      { ext: ".lnk", enabled: true, risk: "low", threats: ["Shortcut.Malicious", "Trojan.LNK", "PUP.Shortcut"] },
      {
        ext: ".docm",
        enabled: true,
        risk: "medium",
        threats: ["Macro.Word.Malicious", "Trojan.Macro", "Office.Malware"],
      },
      {
        ext: ".xlsm",
        enabled: true,
        risk: "medium",
        threats: ["Macro.Excel.Malicious", "Trojan.Spreadsheet", "Office.Macro"],
      },
    ]

    if (savedSettings) {
      try {
        const settings = JSON.parse(savedSettings)
        if (settings.monitoredExtensions) {
          // Merge with threat data
          monitoredExtensions = settings.monitoredExtensions.map((ext) => {
            const defaultExt = monitoredExtensions.find((def) => def.ext === ext.ext)
            return {
              ...ext,
              threats: defaultExt?.threats || ["Generic.Threat", "Unknown.Malware"],
            }
          })
        }
      } catch (error) {
        console.error("Error loading monitored extensions:", error)
      }
    }

    // Filter only enabled extensions
    const enabledExtensions = monitoredExtensions.filter((ext) => ext.enabled)

    const totalFiles = type === "quick" ? 1000 : type === "full" ? 50000 : (folders?.length || 1) * 5000
    let scannedFiles = 0
    let detectedThreats = 0

    const interval = setInterval(() => {
      setScanProgress((prev) => {
        const newProgress = prev + (100 / totalFiles) * 50
        if (newProgress >= 100) {
          clearInterval(interval)
          setIsScanning(false)
          setCurrentFile("")
          setThreatsFound(detectedThreats)
          return 100
        }

        scannedFiles += 50
        setFilesScanned(scannedFiles)

        // Simulate realistic file paths
        const basePaths =
          folders && folders.length > 0
            ? folders
            : ["C:\\Windows\\System32", "C:\\Program Files", "C:\\Users\\Downloads", "C:\\Temp", "C:\\ProgramData"]

        const randomPath = basePaths[Math.floor(Math.random() * basePaths.length)]
        const randomExtension = enabledExtensions[Math.floor(Math.random() * enabledExtensions.length)]
        const fileName = `file${scannedFiles}${randomExtension.ext}`
        const fullPath = `${randomPath}\\${fileName}`

        setCurrentFile(fullPath)

        // Realistic threat detection based on file patterns and risk level
        const riskMultiplier = randomExtension.risk === "high" ? 0.02 : randomExtension.risk === "medium" ? 0.01 : 0.005
        if (Math.random() < riskMultiplier) {
          const threat = randomExtension.threats[Math.floor(Math.random() * randomExtension.threats.length)]
          const newThreat = {
            id: Date.now() + Math.random(),
            file: fullPath,
            threat: threat,
            status: "pending",
            detectedAt: new Date().toISOString(),
            size: `${Math.floor(Math.random() * 5000) + 100} KB`,
            extension: randomExtension.ext,
            riskLevel: randomExtension.risk,
          }

          setScanResults((prev) => [...prev, newThreat])
          detectedThreats++
        }

        return newProgress
      })
    }, 100)
  }

  const startScan = (type: string) => {
    if (type === "custom" && selectedFolders.length === 0) {
      return
    }
    simulateScan(type, type === "custom" ? selectedFolders : undefined)
  }

  const stopScan = () => {
    setIsScanning(false)
    setScanProgress(0)
    setCurrentFile("")
  }

  const clearResults = () => {
    setScanResults([])
    setThreatsFound(0)
  }

  const quarantineSelected = () => {
    const pendingThreats = scanResults.filter((result) => result.status === "pending")
    if (pendingThreats.length === 0) return

    // Move pending threats to quarantine
    const quarantinedThreats = pendingThreats.map((threat) => ({
      id: threat.id,
      name: threat.file.split("\\").pop() || "unknown",
      originalPath: threat.file,
      threat: threat.threat,
      dateQuarantined: new Date().toLocaleString(),
      size: threat.size || `${Math.floor(Math.random() * 5000) + 100} KB`,
      selected: false,
    }))

    setQuarantinedFiles((prev) => [...prev, ...quarantinedThreats])

    // Update scan results to show as quarantined
    const updatedResults = scanResults.map((result) =>
      result.status === "pending" ? { ...result, status: "quarantined" } : result,
    )
    setScanResults(updatedResults)
  }

  const deleteSelected = () => {
    if (confirm("Are you sure you want to permanently delete all pending threats? This action cannot be undone.")) {
      const updatedResults = scanResults.map((result) =>
        result.status === "pending" ? { ...result, status: "deleted" } : result,
      )
      setScanResults(updatedResults)
    }
  }

  const exportResults = () => {
    const dataStr = JSON.stringify(scanResults, null, 2)
    const dataBlob = new Blob([dataStr], { type: "application/json" })
    const url = URL.createObjectURL(dataBlob)
    const link = document.createElement("a")
    link.href = url
    link.download = `vironix-scan-results-${new Date().toISOString().split("T")[0]}.json`
    link.click()
    URL.revokeObjectURL(url)
  }

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold gradient-text-theme">Security Scanner</h1>
          <p className="text-rose-600 dark:text-rose-400 mt-1">Scan your system for threats and malware</p>
        </div>
        <div className="flex items-center space-x-2">
          <Badge variant="outline" className="border-blue-300 text-blue-700 dark:border-blue-600 dark:text-blue-300">
            {filesScanned.toLocaleString()} files scanned
          </Badge>
          <Badge variant="outline" className="border-red-300 text-red-700 dark:border-red-600 dark:text-red-300">
            {threatsFound} threats found
          </Badge>
        </div>
      </div>

      {/* Scan Controls */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <Card className="bg-gradient-to-br from-blue-50 to-cyan-50 dark:from-blue-900/20 dark:to-cyan-900/20 border-blue-200 dark:border-blue-700 rounded-xl shadow-lg transition-all duration-300 hover:shadow-xl hover:scale-[1.02]">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center text-blue-800 dark:text-blue-300">
              <Search className="h-5 w-5 mr-2 animate-float" />
              Quick Scan
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-blue-600 dark:text-blue-500 mb-4">
              Scan critical system areas and running processes
            </p>
            <Button
              data-scan-type="quick"
              onClick={() => startScan("quick")}
              disabled={isScanning}
              className="w-full bg-blue-500 hover:bg-blue-600 text-white rounded-lg transition-all duration-300 hover:scale-105 hover:glow-blue disabled:opacity-50 group relative"
            >
              {isScanning && scanType === "quick" ? (
                <>
                  <Square className="h-4 w-4 mr-2" />
                  Stop Scan
                </>
              ) : (
                <>
                  <Play className="h-4 w-4 mr-2 animate-float" />
                  Start Quick Scan
                </>
              )}

              {/* Hover popup */}
              <div className="absolute -top-12 left-1/2 transform -translate-x-1/2 bg-blue-600 text-white text-xs px-3 py-2 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300 animate-bounce-in whitespace-nowrap">
                🚀 Fast System Check
              </div>
            </Button>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-50 to-violet-50 dark:from-purple-900/20 dark:to-violet-900/20 border-purple-200 dark:border-purple-700 rounded-xl shadow-lg transition-all duration-300 hover:shadow-xl hover:scale-[1.02]">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center text-purple-800 dark:text-purple-300">
              <Search className="h-5 w-5 mr-2 animate-float" />
              Full Scan
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-purple-600 dark:text-purple-500 mb-4">
              Complete system scan including all files and folders
            </p>
            <Button
              onClick={() => startScan("full")}
              disabled={isScanning}
              className="w-full bg-purple-500 hover:bg-purple-600 text-white rounded-lg transition-all duration-300 hover:scale-105 hover:glow-purple disabled:opacity-50 group relative"
            >
              {isScanning && scanType === "full" ? (
                <>
                  <Square className="h-4 w-4 mr-2" />
                  Stop Scan
                </>
              ) : (
                <>
                  <Play className="h-4 w-4 mr-2 animate-float" />
                  Start Full Scan
                </>
              )}

              {/* Hover popup */}
              <div className="absolute -top-12 left-1/2 transform -translate-x-1/2 bg-purple-600 text-white text-xs px-3 py-2 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300 animate-bounce-in whitespace-nowrap">
                🔍 Deep System Scan
              </div>
            </Button>
          </CardContent>
        </Card>

        <div className="md:col-span-2 lg:col-span-1">
          <FolderSelector
            selectedFolders={selectedFolders}
            onFoldersChange={setSelectedFolders}
            onStartScan={() => startScan("custom")}
            isScanning={isScanning && scanType === "custom"}
          />
        </div>
      </div>

      {/* Scan Progress */}
      {isScanning && (
        <Card className="bg-gradient-to-br from-rose-50/50 to-pink-50/50 dark:from-gray-800/50 dark:to-gray-700/50 border-rose-200 dark:border-gray-600 rounded-xl shadow-lg animate-pulse-soft">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-rose-800 dark:text-rose-300">Scan in Progress</CardTitle>
              <Button
                variant="outline"
                size="sm"
                onClick={stopScan}
                className="border-red-300 text-red-700 hover:bg-red-100 dark:border-red-600 dark:text-red-300 dark:hover:bg-red-900/20 transition-all duration-200 hover:scale-105"
              >
                <Square className="h-4 w-4 mr-2" />
                Stop Scan
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <Progress value={scanProgress} className="h-3 glow-progress" />
              <div className="flex justify-between text-sm">
                <span className="text-rose-700 dark:text-rose-400 truncate max-w-md">
                  Scanning: {currentFile || "Initializing..."}
                </span>
                <span className="text-rose-600 dark:text-rose-500">{Math.round(scanProgress)}%</span>
              </div>
              <div className="grid grid-cols-3 gap-4 text-sm">
                <div className="text-center">
                  <div className="font-semibold text-blue-700 dark:text-blue-400">{filesScanned.toLocaleString()}</div>
                  <div className="text-blue-600 dark:text-blue-500">Files Scanned</div>
                </div>
                <div className="text-center">
                  <div className="font-semibold text-red-700 dark:text-red-400">{threatsFound}</div>
                  <div className="text-red-600 dark:text-red-500">Threats Found</div>
                </div>
                <div className="text-center">
                  <div className="font-semibold text-green-700 dark:text-green-400">{scanType.toUpperCase()}</div>
                  <div className="text-green-600 dark:text-green-500">Scan Type</div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Scan Results */}
      <Card className="bg-gradient-to-br from-rose-50/50 to-pink-50/50 dark:from-gray-800/50 dark:to-gray-700/50 border-rose-200 dark:border-gray-600 rounded-xl shadow-lg">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-rose-800 dark:text-rose-300">Scan Results</CardTitle>
            <div className="flex space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={clearResults}
                disabled={scanResults.length === 0}
                className="border-rose-300 text-rose-700 hover:bg-rose-100 dark:border-rose-600 dark:text-rose-300 dark:hover:bg-rose-900/20 transition-all duration-200 hover:scale-105"
              >
                <Trash2 className="h-4 w-4 mr-2" />
                Clear Results
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={exportResults}
                disabled={scanResults.length === 0}
                className="border-rose-300 text-rose-700 hover:bg-rose-100 dark:border-rose-600 dark:text-rose-300 dark:hover:bg-rose-900/20 transition-all duration-200 hover:scale-105"
              >
                <FileText className="h-4 w-4 mr-2" />
                Export Results
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {scanResults.length === 0 ? (
            <div className="text-center py-12">
              <Search className="h-16 w-16 text-rose-300 dark:text-rose-600 mx-auto mb-4 animate-pulse-soft" />
              <h3 className="text-lg font-semibold text-rose-700 dark:text-rose-400 mb-2">
                No scan results to display
              </h3>
              <p className="text-rose-600 dark:text-rose-500">Run a scan to see results here</p>
            </div>
          ) : (
            <>
              <div className="flex items-center justify-between mb-4">
                <div className="flex space-x-2">
                  <Badge variant="destructive" className="animate-pulse-soft">
                    {scanResults.filter((r) => r.status === "pending").length} threats pending
                  </Badge>
                  <Badge
                    variant="outline"
                    className="border-green-300 text-green-700 dark:border-green-600 dark:text-green-300"
                  >
                    {scanResults.filter((r) => r.status === "quarantined").length} quarantined
                  </Badge>
                  <Badge
                    variant="outline"
                    className="border-gray-300 text-gray-700 dark:border-gray-600 dark:text-gray-300"
                  >
                    {scanResults.filter((r) => r.status === "deleted").length} deleted
                  </Badge>
                </div>
                <div className="flex space-x-2">
                  <Button
                    size="sm"
                    onClick={quarantineSelected}
                    disabled={scanResults.filter((r) => r.status === "pending").length === 0}
                    className="bg-orange-500 hover:bg-orange-600 text-white transition-all duration-200 hover:scale-105 hover:glow-orange"
                  >
                    Quarantine All Pending
                  </Button>
                  <Button
                    size="sm"
                    variant="destructive"
                    onClick={deleteSelected}
                    disabled={scanResults.filter((r) => r.status === "pending").length === 0}
                    className="transition-all duration-200 hover:scale-105 hover:glow-red"
                  >
                    Delete All Pending
                  </Button>
                </div>
              </div>
              <div className="space-y-3">
                {scanResults.map((result) => (
                  <div
                    key={result.id}
                    className={`flex items-center justify-between p-4 rounded-lg border transition-all duration-300 hover:scale-[1.01] ${
                      result.status === "pending"
                        ? "bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-700 glow-red-soft"
                        : result.status === "quarantined"
                          ? "bg-orange-50 dark:bg-orange-900/20 border-orange-200 dark:border-orange-700"
                          : "bg-gray-50 dark:bg-gray-800 border-gray-200 dark:border-gray-600"
                    }`}
                  >
                    <div className="flex items-center space-x-3 flex-1 min-w-0">
                      <AlertTriangle
                        className={`h-5 w-5 flex-shrink-0 animate-float ${
                          result.status === "pending" ? "text-red-500 animate-pulse" : "text-orange-500"
                        }`}
                      />
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-rose-800 dark:text-rose-300 truncate">{result.file}</p>
                        <p className="text-sm text-rose-600 dark:text-rose-500">Threat: {result.threat}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Badge
                        variant={
                          result.status === "quarantined"
                            ? "default"
                            : result.status === "deleted"
                              ? "destructive"
                              : "secondary"
                        }
                        className="capitalize"
                      >
                        {result.status}
                      </Badge>
                      {result.status === "pending" && (
                        <div className="flex space-x-1">
                          <Button
                            size="sm"
                            variant="outline"
                            className="text-xs border-orange-300 text-orange-700 hover:bg-orange-100 dark:border-orange-600 dark:text-orange-300 dark:hover:bg-orange-900/20 transition-all duration-200 hover:scale-105"
                            onClick={() => {
                              const updated = scanResults.map((r) =>
                                r.id === result.id ? { ...r, status: "quarantined" } : r,
                              )
                              setScanResults(updated)
                            }}
                          >
                            Quarantine
                          </Button>
                          <Button
                            size="sm"
                            variant="destructive"
                            className="text-xs transition-all duration-200 hover:scale-105"
                            onClick={() => {
                              const updated = scanResults.map((r) =>
                                r.id === result.id ? { ...r, status: "deleted" } : r,
                              )
                              setScanResults(updated)
                            }}
                          >
                            Delete
                          </Button>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
