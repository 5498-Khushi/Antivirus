"use client"

import { useState, useEffect } from "react"
import { Sidebar } from "@/components/sidebar"
import { TitleBar } from "@/components/title-bar"
import { Dashboard } from "@/components/dashboard"
import { Scanner } from "@/components/scanner"
import { Quarantine } from "@/components/quarantine"
import { Firewall } from "@/components/firewall"
import { Settings } from "@/components/settings"

export default function VironixApp() {
  const [activePanel, setActivePanel] = useState("dashboard")
  const [isDarkMode, setIsDarkMode] = useState(false)
  const [isProtected, setIsProtected] = useState(true)
  const [scanResults, setScanResults] = useState([])
  const [quarantinedFiles, setQuarantinedFiles] = useState([])

  // Load dark mode preference
  useEffect(() => {
    const savedTheme = localStorage.getItem("vironix-theme")
    if (savedTheme === "dark") {
      setIsDarkMode(true)
    }
  }, [])

  // Save dark mode preference
  useEffect(() => {
    localStorage.setItem("vironix-theme", isDarkMode ? "dark" : "light")
  }, [isDarkMode])

  const handleQuickScan = () => {
    // Switch to scanner panel and start quick scan
    setActivePanel("scan")
    // Small delay to ensure the scanner component is rendered
    setTimeout(() => {
      const quickScanButton = document.querySelector('[data-scan-type="quick"]') as HTMLButtonElement
      if (quickScanButton) {
        quickScanButton.click()
      }
    }, 100)
  }

  const renderContent = () => {
    switch (activePanel) {
      case "dashboard":
        return (
          <Dashboard
            isProtected={isProtected}
            quarantinedFiles={quarantinedFiles}
            scanResults={scanResults}
            onQuickScan={handleQuickScan}
          />
        )
      case "scan":
        return (
          <Scanner
            scanResults={scanResults}
            setScanResults={setScanResults}
            quarantinedFiles={quarantinedFiles}
            setQuarantinedFiles={setQuarantinedFiles}
          />
        )
      case "quarantine":
        return <Quarantine quarantinedFiles={quarantinedFiles} setQuarantinedFiles={setQuarantinedFiles} />
      case "firewall":
        return <Firewall />
      case "settings":
        return <Settings isProtected={isProtected} setIsProtected={setIsProtected} />
      default:
        return (
          <Dashboard
            isProtected={isProtected}
            quarantinedFiles={quarantinedFiles}
            scanResults={scanResults}
            onQuickScan={handleQuickScan}
          />
        )
    }
  }

  return (
    <div className={`min-h-screen ${isDarkMode ? "dark" : ""}`}>
      <div className="bg-gradient-to-br from-rose-50 to-pink-50 dark:from-gray-900 dark:to-gray-800 min-h-screen transition-all duration-500 ease-in-out">
        <TitleBar isDarkMode={isDarkMode} setIsDarkMode={setIsDarkMode} />
        <div className="flex h-[calc(100vh-40px)]">
          <Sidebar activePanel={activePanel} setActivePanel={setActivePanel} isProtected={isProtected} />
          <main className="flex-1 p-6 overflow-auto animate-fade-in">{renderContent()}</main>
        </div>
      </div>
    </div>
  )
}
