"use client"

import { useRef } from "react"
import { Folder, FolderOpen, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

interface FolderSelectorProps {
  selectedFolders: string[]
  onFoldersChange: (folders: string[]) => void
  onStartScan: () => void
  isScanning: boolean
}

export function FolderSelector({ selectedFolders, onFoldersChange, onStartScan, isScanning }: FolderSelectorProps) {
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleFolderSelect = () => {
    // Create a hidden file input with webkitdirectory attribute
    const input = document.createElement("input")
    input.type = "file"
    input.webkitdirectory = true
    input.multiple = true

    input.onchange = (e) => {
      const files = (e.target as HTMLInputElement).files
      if (files && files.length > 0) {
        // Get the folder path from the first file
        const firstFile = files[0]
        const pathParts = firstFile.webkitRelativePath.split("/")
        const folderPath = pathParts.slice(0, -1).join("/")

        if (folderPath && !selectedFolders.includes(folderPath)) {
          onFoldersChange([...selectedFolders, folderPath])
        }
      }
    }

    input.click()
  }

  const removeFolder = (folderToRemove: string) => {
    onFoldersChange(selectedFolders.filter((folder) => folder !== folderToRemove))
  }

  const clearAllFolders = () => {
    onFoldersChange([])
  }

  return (
    <Card className="bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20 border-green-200 dark:border-green-700 rounded-xl shadow-lg transition-all duration-300 hover:shadow-xl hover:scale-[1.02]">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-2">
            <FolderOpen className="h-5 w-5 text-green-600 dark:text-green-400" />
            <h3 className="text-lg font-semibold text-green-800 dark:text-green-300">Custom Scan</h3>
          </div>
          <Badge
            variant="outline"
            className="border-green-300 text-green-700 dark:border-green-600 dark:text-green-300"
          >
            {selectedFolders.length} folder{selectedFolders.length !== 1 ? "s" : ""} selected
          </Badge>
        </div>

        <p className="text-sm text-green-600 dark:text-green-500 mb-4">
          Select specific folders to scan for threats and malware
        </p>

        {/* Folder Selection Button */}
        <div className="mb-4">
          <Button
            onClick={handleFolderSelect}
            disabled={isScanning}
            className="w-full bg-green-500 hover:bg-green-600 text-white rounded-lg transition-all duration-300 hover:scale-105 hover:glow-green disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Folder className="h-4 w-4 mr-2" />
            Select Folder to Scan
          </Button>
        </div>

        {/* Selected Folders List */}
        {selectedFolders.length > 0 && (
          <div className="mb-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium text-green-800 dark:text-green-300">Selected Folders:</span>
              <Button
                variant="ghost"
                size="sm"
                onClick={clearAllFolders}
                className="text-xs text-green-600 hover:text-green-800 dark:text-green-400 dark:hover:text-green-200 hover:bg-green-100 dark:hover:bg-green-900/20"
              >
                Clear All
              </Button>
            </div>
            <div className="space-y-2 max-h-32 overflow-y-auto">
              {selectedFolders.map((folder, index) => (
                <div
                  key={index}
                  className="flex items-center justify-between p-2 bg-white dark:bg-gray-800 rounded-lg border border-green-200 dark:border-gray-600 transition-all duration-200 hover:bg-green-50 dark:hover:bg-gray-700/50"
                >
                  <div className="flex items-center space-x-2 flex-1 min-w-0">
                    <Folder className="h-4 w-4 text-green-500 flex-shrink-0" />
                    <span className="text-sm text-green-800 dark:text-green-300 truncate" title={folder}>
                      {folder}
                    </span>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => removeFolder(folder)}
                    className="h-6 w-6 p-0 text-green-600 hover:text-red-600 hover:bg-red-100 dark:hover:bg-red-900/20 transition-all duration-200"
                  >
                    <X className="h-3 w-3" />
                  </Button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Start Scan Button */}
        <Button
          onClick={onStartScan}
          disabled={selectedFolders.length === 0 || isScanning}
          className={`w-full rounded-lg transition-all duration-300 hover:scale-105 ${
            selectedFolders.length === 0 || isScanning
              ? "bg-gray-400 cursor-not-allowed"
              : "bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600 text-white hover:glow-green"
          }`}
        >
          {isScanning ? (
            <>
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
              Scanning...
            </>
          ) : (
            <>
              <FolderOpen className="h-4 w-4 mr-2" />
              Start Custom Scan
            </>
          )}
        </Button>

        {selectedFolders.length === 0 && (
          <p className="text-xs text-green-500 dark:text-green-400 mt-2 text-center">
            Select at least one folder to start scanning
          </p>
        )}
      </CardContent>
    </Card>
  )
}
