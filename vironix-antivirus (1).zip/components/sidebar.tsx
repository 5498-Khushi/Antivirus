"use client"

import { Home, Search, Shield, Flame, Settings } from "lucide-react"
import { Button } from "@/components/ui/button"
import Image from "next/image"

interface SidebarProps {
  activePanel: string
  setActivePanel: (panel: string) => void
  isProtected: boolean
}

const navigationItems = [
  { id: "dashboard", label: "Home", icon: Home },
  { id: "scan", label: "Scan", icon: Search },
  { id: "quarantine", label: "Quarantine", icon: Shield },
  { id: "firewall", label: "Firewall", icon: Flame },
  { id: "settings", label: "Settings", icon: Settings },
]

export function Sidebar({ activePanel, setActivePanel, isProtected }: SidebarProps) {
  return (
    <div className="w-64 bg-gradient-to-b from-rose-100/80 to-pink-100/80 dark:from-gray-800/80 dark:to-gray-700/80 backdrop-blur-sm border-r border-rose-200 dark:border-gray-600 p-4 transition-all duration-300 animate-slide-in">
      {/* Logo */}
      <div className="flex items-center justify-center mb-8 p-4">
        <div className="flex items-center space-x-3 group cursor-pointer">
          <div className="relative">
            <Image
              src="/vironix-logo.png"
              alt="Vironix Logo"
              width={40}
              height={40}
              className="transition-all duration-300 group-hover:scale-110 animate-glow"
            />
          </div>
          <div>
            <h1 className="text-xl font-bold gradient-text-theme transition-all duration-300 group-hover:scale-105">
              VIRONIX
            </h1>
            <p className="text-xs text-rose-500 dark:text-rose-400">Advanced Security</p>
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="space-y-2">
        {navigationItems.map((item) => {
          const Icon = item.icon
          const isActive = activePanel === item.id

          return (
            <Button
              key={item.id}
              variant="ghost"
              onClick={() => setActivePanel(item.id)}
              className={`w-full justify-start h-12 rounded-xl transition-all duration-300 transform hover:scale-105 ${
                isActive
                  ? "bg-gradient-to-r from-rose-200 to-pink-200 dark:from-rose-800/50 dark:to-pink-800/50 text-rose-800 dark:text-rose-200 shadow-lg glow-active scale-105"
                  : "hover:bg-rose-50 dark:hover:bg-gray-700/50 text-rose-700 dark:text-rose-300 hover:glow-soft"
              }`}
            >
              <Icon className={`h-5 w-5 mr-3 transition-all duration-300 ${isActive ? "animate-pulse-soft" : ""}`} />
              <span className="font-medium">{item.label}</span>
            </Button>
          )
        })}
      </nav>

      {/* Status Indicator */}
      <div
        className={`mt-8 p-4 rounded-xl border transition-all duration-300 hover:scale-105 ${
          isProtected
            ? "bg-gradient-to-r from-green-100 to-emerald-100 dark:from-green-900/30 dark:to-emerald-900/30 border-green-200 dark:border-green-700 glow-green"
            : "bg-gradient-to-r from-red-100 to-orange-100 dark:from-red-900/30 dark:to-orange-900/30 border-red-200 dark:border-red-700 glow-red"
        }`}
      >
        <div className="flex items-center space-x-2">
          <div
            className={`w-3 h-3 rounded-full ${isProtected ? "bg-green-500 animate-pulse-soft" : "bg-red-500 animate-pulse"}`}
          ></div>
          <span
            className={`text-sm font-medium ${isProtected ? "text-green-800 dark:text-green-300" : "text-red-800 dark:text-red-300"}`}
          >
            {isProtected ? "Protected" : "At Risk"}
          </span>
        </div>
        <p
          className={`text-xs mt-1 ${isProtected ? "text-green-600 dark:text-green-400" : "text-red-600 dark:text-red-400"}`}
        >
          {isProtected ? "Real-time protection active" : "Protection disabled"}
        </p>
      </div>
    </div>
  )
}
