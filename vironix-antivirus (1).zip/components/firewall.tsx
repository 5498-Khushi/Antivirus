"use client"

import { useState } from "react"
import { Flame, Shield, Globe, Wifi, AlertTriangle, CheckCircle, Plus, Edit, Trash2 } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"

interface FirewallRule {
  id: number
  name: string
  action: "allow" | "block"
  direction: "inbound" | "outbound" | "both"
  protocol: "TCP" | "UDP" | "ICMP" | "All"
  port: string
  ipAddress: string
  enabled: boolean
  description: string
}

export function Firewall() {
  const [firewallEnabled, setFirewallEnabled] = useState(true)
  const [networkProtection, setNetworkProtection] = useState(true)
  const [webProtection, setWebProtection] = useState(true)
  const [isAddRuleOpen, setIsAddRuleOpen] = useState(false)
  const [editingRule, setEditingRule] = useState<FirewallRule | null>(null)

  const [firewallRules, setFirewallRules] = useState<FirewallRule[]>([
    {
      id: 1,
      name: "Block Incoming Connections",
      action: "block",
      direction: "inbound",
      protocol: "All",
      port: "*",
      ipAddress: "*",
      enabled: true,
      description: "Prevents unauthorized access from external sources",
    },
    {
      id: 2,
      name: "Allow Outbound HTTP/HTTPS",
      action: "allow",
      direction: "outbound",
      protocol: "TCP",
      port: "80,443",
      ipAddress: "*",
      enabled: true,
      description: "Permits web browsing and secure connections",
    },
    {
      id: 3,
      name: "Block Malicious IPs",
      action: "block",
      direction: "both",
      protocol: "All",
      port: "*",
      ipAddress: "192.168.1.100,10.0.0.50",
      enabled: true,
      description: "Blocks known malicious IP addresses",
    },
    {
      id: 4,
      name: "Allow DNS Queries",
      action: "allow",
      direction: "outbound",
      protocol: "UDP",
      port: "53",
      ipAddress: "*",
      enabled: true,
      description: "Allows domain name resolution",
    },
  ])

  const [newRule, setNewRule] = useState<Partial<FirewallRule>>({
    name: "",
    action: "block",
    direction: "inbound",
    protocol: "TCP",
    port: "",
    ipAddress: "",
    description: "",
  })

  const [blockedConnections] = useState([
    {
      id: 1,
      source: "192.168.1.100",
      destination: "malicious-site.com",
      port: 443,
      protocol: "HTTPS",
      time: "14:32:15",
      threat: "Malware C&C",
      blocked: 247,
      attempts: 1250,
    },
    {
      id: 2,
      source: "10.0.0.50",
      destination: "suspicious-domain.net",
      port: 80,
      protocol: "HTTP",
      time: "14:28:42",
      threat: "Phishing",
      blocked: 89,
      attempts: 340,
    },
    {
      id: 3,
      source: "192.168.1.105",
      destination: "botnet-server.org",
      port: 8080,
      protocol: "TCP",
      time: "14:25:18",
      threat: "Botnet",
      blocked: 156,
      attempts: 890,
    },
  ])

  const toggleRule = (id: number) => {
    setFirewallRules((rules) => rules.map((rule) => (rule.id === id ? { ...rule, enabled: !rule.enabled } : rule)))
  }

  const addRule = () => {
    if (!newRule.name || !newRule.port || !newRule.ipAddress) {
      alert("Please fill in all required fields")
      return
    }

    const rule: FirewallRule = {
      id: Date.now(),
      name: newRule.name!,
      action: newRule.action as "allow" | "block",
      direction: newRule.direction as "inbound" | "outbound" | "both",
      protocol: newRule.protocol as "TCP" | "UDP" | "ICMP" | "All",
      port: newRule.port!,
      ipAddress: newRule.ipAddress!,
      enabled: true,
      description: newRule.description || "",
    }

    setFirewallRules((prev) => [...prev, rule])
    setNewRule({
      name: "",
      action: "block",
      direction: "inbound",
      protocol: "TCP",
      port: "",
      ipAddress: "",
      description: "",
    })
    setIsAddRuleOpen(false)
  }

  const editRule = (rule: FirewallRule) => {
    setEditingRule(rule)
    setNewRule(rule)
    setIsAddRuleOpen(true)
  }

  const updateRule = () => {
    if (!editingRule || !newRule.name || !newRule.port || !newRule.ipAddress) {
      alert("Please fill in all required fields")
      return
    }

    setFirewallRules((rules) =>
      rules.map((rule) =>
        rule.id === editingRule.id
          ? {
              ...rule,
              name: newRule.name!,
              action: newRule.action as "allow" | "block",
              direction: newRule.direction as "inbound" | "outbound" | "both",
              protocol: newRule.protocol as "TCP" | "UDP" | "ICMP" | "All",
              port: newRule.port!,
              ipAddress: newRule.ipAddress!,
              description: newRule.description || "",
            }
          : rule,
      ),
    )

    setEditingRule(null)
    setNewRule({
      name: "",
      action: "block",
      direction: "inbound",
      protocol: "TCP",
      port: "",
      ipAddress: "",
      description: "",
    })
    setIsAddRuleOpen(false)
  }

  const deleteRule = (id: number) => {
    if (confirm("Are you sure you want to delete this firewall rule?")) {
      setFirewallRules((rules) => rules.filter((rule) => rule.id !== id))
    }
  }

  const handleFirewallToggle = (enabled: boolean) => {
    setFirewallEnabled(enabled)
    if (!enabled) {
      setNetworkProtection(false)
      setWebProtection(false)
    }
  }

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold gradient-text-theme">Firewall Protection</h1>
          <p className="text-rose-600 dark:text-rose-400 mt-1">
            Monitor and control network traffic to protect your system
          </p>
        </div>
        <div className="flex items-center space-x-2">
          <Badge
            variant={firewallEnabled ? "default" : "destructive"}
            className={`${firewallEnabled ? "bg-green-500 animate-pulse-soft" : "animate-pulse"}`}
          >
            {firewallEnabled ? "Active" : "Disabled"}
          </Badge>
        </div>
      </div>

      {/* Firewall Controls */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="bg-gradient-to-br from-red-50 to-orange-50 dark:from-red-900/20 dark:to-orange-900/20 border-red-200 dark:border-red-700 rounded-xl shadow-lg transition-all duration-300 hover:shadow-xl hover:scale-[1.02] card-hover">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center text-red-800 dark:text-red-300">
              <Flame className="h-5 w-5 mr-2 animate-float" />
              Firewall
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between mb-4">
              <span className="text-sm text-red-700 dark:text-red-400">Enable Firewall</span>
              <Switch
                checked={firewallEnabled}
                onCheckedChange={handleFirewallToggle}
                className="data-[state=checked]:bg-red-500"
              />
            </div>
            <p className="text-xs text-red-600 dark:text-red-500">
              {firewallEnabled ? "Firewall is actively blocking threats" : "Firewall protection is disabled"}
            </p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-blue-50 to-cyan-50 dark:from-blue-900/20 dark:to-cyan-900/20 border-blue-200 dark:border-blue-700 rounded-xl shadow-lg transition-all duration-300 hover:shadow-xl hover:scale-[1.02] card-hover">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center text-blue-800 dark:text-blue-300">
              <Wifi className="h-5 w-5 mr-2 animate-float" />
              Network Protection
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between mb-4">
              <span className="text-sm text-blue-700 dark:text-blue-400">Enable Network Shield</span>
              <Switch
                checked={networkProtection && firewallEnabled}
                onCheckedChange={setNetworkProtection}
                disabled={!firewallEnabled}
                className="data-[state=checked]:bg-blue-500"
              />
            </div>
            <p className="text-xs text-blue-600 dark:text-blue-500">
              {networkProtection && firewallEnabled ? "Monitoring network connections" : "Network monitoring disabled"}
            </p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20 border-green-200 dark:border-green-700 rounded-xl shadow-lg transition-all duration-300 hover:shadow-xl hover:scale-[1.02] card-hover">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center text-green-800 dark:text-green-300">
              <Globe className="h-5 w-5 mr-2 animate-float" />
              Web Protection
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between mb-4">
              <span className="text-sm text-green-700 dark:text-green-400">Enable Web Shield</span>
              <Switch
                checked={webProtection && firewallEnabled}
                onCheckedChange={setWebProtection}
                disabled={!firewallEnabled}
                className="data-[state=checked]:bg-green-500"
              />
            </div>
            <p className="text-xs text-green-600 dark:text-green-500">
              {webProtection && firewallEnabled ? "Blocking malicious websites" : "Web protection disabled"}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Firewall Status */}
      <Card className="bg-gradient-to-br from-rose-50/50 to-pink-50/50 dark:from-gray-800/50 dark:to-gray-700/50 border-rose-200 dark:border-gray-600 rounded-xl shadow-lg">
        <CardHeader>
          <CardTitle className="text-rose-800 dark:text-rose-300">Protection Status</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="flex items-center space-x-3 p-3 bg-green-50 dark:bg-green-900/20 rounded-lg transition-all duration-300 hover:scale-105 cursor-pointer group relative">
              <CheckCircle className="h-8 w-8 text-green-500 animate-float" />
              <div>
                <p className="font-semibold text-green-800 dark:text-green-300">Inbound</p>
                <p className="text-sm text-green-600 dark:text-green-500">Protected</p>
              </div>
              <div className="absolute -top-2 -right-2 bg-green-500 text-white text-xs px-2 py-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300 animate-bounce-in">
                ✓ Secure
              </div>
            </div>

            <div className="flex items-center space-x-3 p-3 bg-green-50 dark:bg-green-900/20 rounded-lg transition-all duration-300 hover:scale-105 cursor-pointer group relative">
              <CheckCircle className="h-8 w-8 text-green-500 animate-float" />
              <div>
                <p className="font-semibold text-green-800 dark:text-green-300">Outbound</p>
                <p className="text-sm text-green-600 dark:text-green-500">Monitored</p>
              </div>
              <div className="absolute -top-2 -right-2 bg-blue-500 text-white text-xs px-2 py-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300 animate-bounce-in">
                👁️ Watching
              </div>
            </div>

            <div className="flex items-center space-x-3 p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg transition-all duration-300 hover:scale-105 cursor-pointer group relative">
              <Shield className="h-8 w-8 text-blue-500 animate-float" />
              <div>
                <p className="font-semibold text-blue-800 dark:text-blue-300">Blocked Today</p>
                <p className="text-sm text-blue-600 dark:text-blue-500">247 attempts</p>
              </div>
              <div className="absolute -top-2 -right-2 bg-red-500 text-white text-xs px-2 py-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300 animate-bounce-in">
                🛡️ Blocked
              </div>
            </div>

            <div className="flex items-center space-x-3 p-3 bg-orange-50 dark:bg-orange-900/20 rounded-lg transition-all duration-300 hover:scale-105 cursor-pointer group relative">
              <AlertTriangle className="h-8 w-8 text-orange-500 animate-float" />
              <div>
                <p className="font-semibold text-orange-800 dark:text-orange-300">Threats</p>
                <p className="text-sm text-orange-600 dark:text-orange-500">3 blocked</p>
              </div>
              <div className="absolute -top-2 -right-2 bg-orange-500 text-white text-xs px-2 py-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300 animate-bounce-in">
                ⚠️ Threats
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Recent Blocked Connections */}
      <Card className="bg-gradient-to-br from-rose-50/50 to-pink-50/50 dark:from-gray-800/50 dark:to-gray-700/50 border-rose-200 dark:border-gray-600 rounded-xl shadow-lg">
        <CardHeader>
          <CardTitle className="text-rose-800 dark:text-rose-300">Recent Blocked Connections</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {blockedConnections.map((connection) => (
              <div
                key={connection.id}
                className="p-4 bg-white dark:bg-gray-800 rounded-lg border border-rose-200 dark:border-gray-600 transition-all duration-300 hover:scale-[1.01] cursor-pointer group relative"
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center space-x-2">
                    <AlertTriangle className="h-4 w-4 text-red-500 animate-float" />
                    <span className="font-semibold text-rose-800 dark:text-rose-300">{connection.destination}</span>
                    <Badge variant="destructive" className="text-xs animate-pulse-soft">
                      {connection.threat}
                    </Badge>
                  </div>
                  <span className="text-sm text-rose-600 dark:text-rose-500">{connection.time}</span>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-sm text-rose-600 dark:text-rose-500">
                  <div>
                    <span className="font-medium">Source:</span> {connection.source}
                  </div>
                  <div>
                    <span className="font-medium">Port:</span> {connection.port}
                  </div>
                  <div>
                    <span className="font-medium">Protocol:</span> {connection.protocol}
                  </div>
                  <div>
                    <span className="font-medium">Action:</span> Blocked
                  </div>
                </div>

                {/* Hover popup with detailed stats */}
                <div className="absolute top-0 right-0 bg-red-500 text-white text-xs px-3 py-2 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-300 animate-bounce-in z-10">
                  <div className="text-center">
                    <div className="font-bold">{connection.blocked}</div>
                    <div>Blocked</div>
                  </div>
                  <div className="text-center mt-1">
                    <div className="font-bold">{connection.attempts}</div>
                    <div>Attempts</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Firewall Rules */}
      <Card className="bg-gradient-to-br from-purple-50 to-violet-50 dark:from-purple-900/20 dark:to-violet-900/20 border-purple-200 dark:border-purple-700 rounded-xl shadow-lg">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-purple-800 dark:text-purple-300">Firewall Rules</CardTitle>
            <Dialog open={isAddRuleOpen} onOpenChange={setIsAddRuleOpen}>
              <DialogTrigger asChild>
                <Button
                  className="bg-purple-500 hover:bg-purple-600 text-white transition-all duration-300 hover:scale-105 hover:glow-purple"
                  onClick={() => {
                    setEditingRule(null)
                    setNewRule({
                      name: "",
                      action: "block",
                      direction: "inbound",
                      protocol: "TCP",
                      port: "",
                      ipAddress: "",
                      description: "",
                    })
                  }}
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Add Rule
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-md">
                <DialogHeader>
                  <DialogTitle>{editingRule ? "Edit Firewall Rule" : "Add New Firewall Rule"}</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="rule-name">Rule Name *</Label>
                    <Input
                      id="rule-name"
                      value={newRule.name || ""}
                      onChange={(e) => setNewRule((prev) => ({ ...prev, name: e.target.value }))}
                      placeholder="Enter rule name"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="rule-action">Action</Label>
                      <Select
                        value={newRule.action}
                        onValueChange={(value) =>
                          setNewRule((prev) => ({ ...prev, action: value as "allow" | "block" }))
                        }
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="allow">Allow</SelectItem>
                          <SelectItem value="block">Block</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="rule-direction">Direction</Label>
                      <Select
                        value={newRule.direction}
                        onValueChange={(value) =>
                          setNewRule((prev) => ({ ...prev, direction: value as "inbound" | "outbound" | "both" }))
                        }
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="inbound">Inbound</SelectItem>
                          <SelectItem value="outbound">Outbound</SelectItem>
                          <SelectItem value="both">Both</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="rule-protocol">Protocol</Label>
                      <Select
                        value={newRule.protocol}
                        onValueChange={(value) =>
                          setNewRule((prev) => ({ ...prev, protocol: value as "TCP" | "UDP" | "ICMP" | "All" }))
                        }
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="TCP">TCP</SelectItem>
                          <SelectItem value="UDP">UDP</SelectItem>
                          <SelectItem value="ICMP">ICMP</SelectItem>
                          <SelectItem value="All">All</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="rule-port">Port *</Label>
                      <Input
                        id="rule-port"
                        value={newRule.port || ""}
                        onChange={(e) => setNewRule((prev) => ({ ...prev, port: e.target.value }))}
                        placeholder="80,443 or *"
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="rule-ip">IP Address *</Label>
                    <Input
                      id="rule-ip"
                      value={newRule.ipAddress || ""}
                      onChange={(e) => setNewRule((prev) => ({ ...prev, ipAddress: e.target.value }))}
                      placeholder="192.168.1.1 or *"
                    />
                  </div>

                  <div>
                    <Label htmlFor="rule-description">Description</Label>
                    <Input
                      id="rule-description"
                      value={newRule.description || ""}
                      onChange={(e) => setNewRule((prev) => ({ ...prev, description: e.target.value }))}
                      placeholder="Optional description"
                    />
                  </div>

                  <div className="flex space-x-2">
                    <Button
                      onClick={editingRule ? updateRule : addRule}
                      className="flex-1 bg-purple-500 hover:bg-purple-600 text-white transition-all duration-300 hover:scale-105"
                    >
                      {editingRule ? "Update Rule" : "Add Rule"}
                    </Button>
                    <Button variant="outline" onClick={() => setIsAddRuleOpen(false)} className="flex-1">
                      Cancel
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {firewallRules.map((rule) => (
              <div
                key={rule.id}
                className={`flex items-center justify-between p-3 rounded-lg border transition-all duration-300 hover:scale-[1.01] ${
                  rule.enabled
                    ? "bg-white dark:bg-gray-800 border-purple-200 dark:border-gray-600"
                    : "bg-gray-50 dark:bg-gray-700 border-gray-300 dark:border-gray-500 opacity-60"
                }`}
              >
                <div className="flex items-center space-x-3 flex-1">
                  <Switch
                    checked={rule.enabled && firewallEnabled}
                    onCheckedChange={() => toggleRule(rule.id)}
                    disabled={!firewallEnabled}
                    className="data-[state=checked]:bg-purple-500"
                  />
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-1">
                      <p className="font-medium text-purple-800 dark:text-purple-300">{rule.name}</p>
                      <Badge variant={rule.action === "allow" ? "default" : "destructive"} className="text-xs">
                        {rule.action.toUpperCase()}
                      </Badge>
                      <Badge variant="outline" className="text-xs">
                        {rule.direction.toUpperCase()}
                      </Badge>
                    </div>
                    <p className="text-sm text-purple-600 dark:text-purple-500">
                      {rule.protocol} | Port: {rule.port} | IP: {rule.ipAddress}
                    </p>
                    {rule.description && (
                      <p className="text-xs text-purple-500 dark:text-purple-400 mt-1">{rule.description}</p>
                    )}
                  </div>
                </div>
                <div className="flex space-x-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => editRule(rule)}
                    className="h-8 w-8 p-0 hover:bg-purple-100 dark:hover:bg-purple-900/20 transition-all duration-200 hover:scale-110"
                  >
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => deleteRule(rule.id)}
                    className="h-8 w-8 p-0 hover:bg-red-100 dark:hover:bg-red-900/20 text-red-600 transition-all duration-200 hover:scale-110"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
