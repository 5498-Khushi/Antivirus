"use client"

import { Shield, RotateCcw, Trash2, AlertTriangle, Download } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"

interface QuarantineProps {
  quarantinedFiles: any[]
  setQuarantinedFiles: (files: any[]) => void
}

export function Quarantine({ quarantinedFiles, setQuarantinedFiles }: QuarantineProps) {
  const toggleFileSelection = (id: number) => {
    setQuarantinedFiles(quarantinedFiles.map((file) => (file.id === id ? { ...file, selected: !file.selected } : file)))
  }

  const toggleSelectAll = () => {
    const allSelected = quarantinedFiles.every((file) => file.selected)
    setQuarantinedFiles(quarantinedFiles.map((file) => ({ ...file, selected: !allSelected })))
  }

  const restoreSelected = () => {
    const selectedFiles = quarantinedFiles.filter((file) => file.selected)
    if (selectedFiles.length === 0) return

    if (
      confirm(
        `Are you sure you want to restore ${selectedFiles.length} file(s)? This will return them to their original locations.`,
      )
    ) {
      setQuarantinedFiles(quarantinedFiles.filter((file) => !file.selected))
    }
  }

  const deleteSelected = () => {
    const selectedFiles = quarantinedFiles.filter((file) => file.selected)
    if (selectedFiles.length === 0) return

    if (
      confirm(
        `Are you sure you want to permanently delete ${selectedFiles.length} file(s)? This action cannot be undone.`,
      )
    ) {
      setQuarantinedFiles(quarantinedFiles.filter((file) => !file.selected))
    }
  }

  const restoreFile = (id: number) => {
    if (confirm("Are you sure you want to restore this file? It will be returned to its original location.")) {
      setQuarantinedFiles(quarantinedFiles.filter((file) => file.id !== id))
    }
  }

  const deleteFile = (id: number) => {
    if (confirm("Are you sure you want to permanently delete this file? This action cannot be undone.")) {
      setQuarantinedFiles(quarantinedFiles.filter((file) => file.id !== id))
    }
  }

  const exportQuarantineReport = () => {
    const report = {
      exportDate: new Date().toISOString(),
      totalFiles: quarantinedFiles.length,
      files: quarantinedFiles.map((file) => ({
        name: file.name,
        originalPath: file.originalPath,
        threat: file.threat,
        dateQuarantined: file.dateQuarantined,
        size: file.size,
      })),
    }

    const dataStr = JSON.stringify(report, null, 2)
    const dataBlob = new Blob([dataStr], { type: "application/json" })
    const url = URL.createObjectURL(dataBlob)
    const link = document.createElement("a")
    link.href = url
    link.download = `vironix-quarantine-report-${new Date().toISOString().split("T")[0]}.json`
    link.click()
    URL.revokeObjectURL(url)
  }

  const selectedCount = quarantinedFiles.filter((file) => file.selected).length

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold gradient-text-theme">Quarantine Manager</h1>
          <p className="text-rose-600 dark:text-rose-400 mt-1">Manage isolated threats and suspicious files</p>
        </div>
        <div className="flex items-center space-x-2">
          <Badge
            variant="outline"
            className="border-orange-300 text-orange-700 dark:border-orange-600 dark:text-orange-300 animate-pulse-soft"
          >
            {quarantinedFiles.length} items quarantined
          </Badge>
          <Button
            variant="outline"
            size="sm"
            onClick={exportQuarantineReport}
            disabled={quarantinedFiles.length === 0}
            className="border-blue-300 text-blue-700 hover:bg-blue-100 dark:border-blue-600 dark:text-blue-300 dark:hover:bg-blue-900/20 transition-all duration-200 hover:scale-105"
          >
            <Download className="h-4 w-4 mr-2" />
            Export Report
          </Button>
        </div>
      </div>

      {/* Action Bar */}
      <Card className="bg-gradient-to-br from-rose-50/50 to-pink-50/50 dark:from-gray-800/50 dark:to-gray-700/50 border-rose-200 dark:border-gray-600 rounded-xl shadow-lg">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Checkbox
                  checked={quarantinedFiles.length > 0 && quarantinedFiles.every((file) => file.selected)}
                  onCheckedChange={toggleSelectAll}
                  disabled={quarantinedFiles.length === 0}
                />
                <span className="text-sm text-rose-700 dark:text-rose-400">Select All ({selectedCount} selected)</span>
              </div>
            </div>
            <div className="flex space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={restoreSelected}
                disabled={selectedCount === 0}
                className="border-green-300 text-green-700 hover:bg-green-100 dark:border-green-600 dark:text-green-300 dark:hover:bg-green-900/20 transition-all duration-200 hover:scale-105 hover:glow-green"
              >
                <RotateCcw className="h-4 w-4 mr-2" />
                Restore ({selectedCount})
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={deleteSelected}
                disabled={selectedCount === 0}
                className="border-red-300 text-red-700 hover:bg-red-100 dark:border-red-600 dark:text-red-300 dark:hover:bg-red-900/20 transition-all duration-200 hover:scale-105 hover:glow-red"
              >
                <Trash2 className="h-4 w-4 mr-2" />
                Delete ({selectedCount})
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Quarantined Files List */}
      <Card className="bg-gradient-to-br from-rose-50/50 to-pink-50/50 dark:from-gray-800/50 dark:to-gray-700/50 border-rose-200 dark:border-gray-600 rounded-xl shadow-lg">
        <CardHeader>
          <CardTitle className="flex items-center text-rose-800 dark:text-rose-300">
            <Shield className="h-5 w-5 mr-2" />
            Quarantined Files
          </CardTitle>
        </CardHeader>
        <CardContent>
          {quarantinedFiles.length === 0 ? (
            <div className="text-center py-16">
              <Shield className="h-20 w-20 text-rose-300 dark:text-rose-600 mx-auto mb-6 animate-pulse-soft" />
              <h3 className="text-xl font-semibold text-rose-700 dark:text-rose-400 mb-3">No quarantined files</h3>
              <p className="text-rose-600 dark:text-rose-500 mb-4">Threats detected by the scanner will appear here</p>
              <div className="inline-flex items-center px-4 py-2 bg-green-100 dark:bg-green-900/20 rounded-lg border border-green-200 dark:border-green-700">
                <Shield className="h-4 w-4 text-green-600 mr-2" />
                <span className="text-sm text-green-700 dark:text-green-400">Your system is clean</span>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              {quarantinedFiles.map((file) => (
                <div
                  key={file.id}
                  className={`p-4 rounded-lg border transition-all duration-300 hover:scale-[1.01] ${
                    file.selected
                      ? "bg-rose-100 dark:bg-rose-900/20 border-rose-300 dark:border-rose-600 glow-rose-soft"
                      : "bg-white dark:bg-gray-800 border-rose-200 dark:border-gray-600 hover:bg-rose-50 dark:hover:bg-gray-700/50"
                  }`}
                >
                  <div className="flex items-start space-x-4">
                    <Checkbox
                      checked={file.selected}
                      onCheckedChange={() => toggleFileSelection(file.id)}
                      className="mt-1"
                    />

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center space-x-2 mb-3">
                        <AlertTriangle className="h-5 w-5 text-orange-500 flex-shrink-0 animate-pulse-soft" />
                        <h4 className="font-semibold text-rose-800 dark:text-rose-300 truncate">{file.name}</h4>
                        <Badge variant="destructive" className="text-xs animate-pulse-soft">
                          {file.threat}
                        </Badge>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-sm text-rose-600 dark:text-rose-500">
                        <div>
                          <span className="font-medium text-rose-700 dark:text-rose-400">Original Path:</span>
                          <p className="truncate" title={file.originalPath}>
                            {file.originalPath}
                          </p>
                        </div>
                        <div>
                          <span className="font-medium text-rose-700 dark:text-rose-400">Quarantined:</span>
                          <p>{file.dateQuarantined}</p>
                        </div>
                        <div>
                          <span className="font-medium text-rose-700 dark:text-rose-400">Size:</span>
                          <p>{file.size}</p>
                        </div>
                      </div>
                    </div>

                    <div className="flex space-x-2 flex-shrink-0">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => restoreFile(file.id)}
                        className="border-green-300 text-green-700 hover:bg-green-100 dark:border-green-600 dark:text-green-300 dark:hover:bg-green-900/20 transition-all duration-200 hover:scale-110 hover:glow-green"
                        title="Restore file to original location"
                      >
                        <RotateCcw className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => deleteFile(file.id)}
                        className="border-red-300 text-red-700 hover:bg-red-100 dark:border-red-600 dark:text-red-300 dark:hover:bg-red-900/20 transition-all duration-200 hover:scale-110 hover:glow-red"
                        title="Permanently delete file"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Quarantine Info */}
      <Card className="bg-gradient-to-br from-blue-50 to-cyan-50 dark:from-blue-900/20 dark:to-cyan-900/20 border-blue-200 dark:border-blue-700 rounded-xl shadow-lg">
        <CardHeader>
          <CardTitle className="text-blue-800 dark:text-blue-300">About Quarantine</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4 text-sm text-blue-700 dark:text-blue-400">
            <div className="flex items-start space-x-3">
              <Shield className="h-5 w-5 text-blue-600 mt-0.5 flex-shrink-0" />
              <div>
                <p className="font-semibold mb-1">Quarantine Protection</p>
                <p>
                  Files in quarantine are encrypted and isolated to prevent them from harming your system while
                  preserving them for analysis or restoration.
                </p>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <RotateCcw className="h-5 w-5 text-green-600 mt-0.5 flex-shrink-0" />
              <div>
                <p className="font-semibold mb-1">Restore Files</p>
                <p>
                  Returns the file to its original location. Only restore files if you're certain they're not malicious.
                </p>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <Trash2 className="h-5 w-5 text-red-600 mt-0.5 flex-shrink-0" />
              <div>
                <p className="font-semibold mb-1">Delete Files</p>
                <p>Permanently removes the file from your system. This action cannot be undone.</p>
              </div>
            </div>
            <div className="mt-4 p-3 bg-blue-100 dark:bg-blue-900/30 rounded-lg border border-blue-200 dark:border-blue-700">
              <p className="text-blue-800 dark:text-blue-300 font-medium">
                ⚠️ Security Reminder: Only restore files if you're absolutely certain they're safe. When in doubt, keep
                them quarantined or delete them.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
