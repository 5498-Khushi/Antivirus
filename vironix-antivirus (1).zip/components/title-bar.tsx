"use client"

import { Minus, Square, X, Moon, Sun } from "lucide-react"
import { Button } from "@/components/ui/button"
import Image from "next/image"

interface TitleBarProps {
  isDarkMode: boolean
  setIsDarkMode: (value: boolean) => void
}

export function TitleBar({ isDarkMode, setIsDarkMode }: TitleBarProps) {
  const handleMinimize = () => {
    // In a real desktop app, this would minimize the window
    console.log("Minimize window")
  }

  const handleMaximize = () => {
    // In a real desktop app, this would maximize/restore the window
    console.log("Maximize/Restore window")
  }

  const handleClose = () => {
    // In a real desktop app, this would close the window
    if (confirm("Are you sure you want to close Vironix Antivirus?")) {
      console.log("Close application")
    }
  }

  return (
    <div className="h-10 bg-gradient-to-r from-rose-100 to-pink-100 dark:from-gray-800 dark:to-gray-700 flex items-center justify-between px-4 border-b border-rose-200 dark:border-gray-600 transition-all duration-300 backdrop-blur-sm">
      <div className="flex items-center space-x-3">
        <div className="relative">
          <Image src="/vironix-logo.png" alt="Vironix Logo" width={24} height={24} className="animate-glow" />
        </div>
        <span className="text-sm font-bold gradient-text-theme">Vironix Antivirus</span>
        <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse-soft"></div>
      </div>

      <div className="flex items-center space-x-1">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setIsDarkMode(!isDarkMode)}
          className="h-7 w-7 p-0 hover:bg-rose-200 dark:hover:bg-gray-600 text-rose-700 dark:text-rose-300 transition-all duration-200 hover:scale-110 hover:glow-soft"
        >
          {isDarkMode ? <Sun className="h-3 w-3" /> : <Moon className="h-3 w-3" />}
        </Button>

        <Button
          variant="ghost"
          size="sm"
          onClick={handleMinimize}
          className="h-7 w-7 p-0 hover:bg-rose-200 dark:hover:bg-gray-600 text-rose-700 dark:text-rose-300 transition-all duration-200 hover:scale-110"
        >
          <Minus className="h-3 w-3" />
        </Button>

        <Button
          variant="ghost"
          size="sm"
          onClick={handleMaximize}
          className="h-7 w-7 p-0 hover:bg-rose-200 dark:hover:bg-gray-600 text-rose-700 dark:text-rose-300 transition-all duration-200 hover:scale-110"
        >
          <Square className="h-3 w-3" />
        </Button>

        <Button
          variant="ghost"
          size="sm"
          onClick={handleClose}
          className="h-7 w-7 p-0 hover:bg-red-200 dark:hover:bg-red-600 text-rose-700 dark:text-rose-300 hover:text-red-700 transition-all duration-200 hover:scale-110"
        >
          <X className="h-3 w-3" />
        </Button>
      </div>
    </div>
  )
}
